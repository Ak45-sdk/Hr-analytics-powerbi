// ============================================================
// HR Analytics – Power Query (M) scripts
// Create each query in Power BI: Home > Transform data > New Source > Blank Query > Advanced Editor
// Replace DataFolder with your local path (or use a Parameter named DataFolder).
// ============================================================

// ---------- Parameter: DataFolder ----------
// "C:\HR-Analytics\data\raw\" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]


// ---------- Query: Employees ----------
let
    Source = Csv.Document(File.Contents(DataFolder & "employees.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    Typed = Table.TransformColumnTypes(Promoted, {
        {"EmployeeID", type text}, {"Gender", type text}, {"Age", Int64.Type}, {"Education", type text},
        {"Department", type text}, {"JobRole", type text}, {"HireDate", type date}, {"TerminationDate", type date},
        {"ReasonForLeaving", type text}, {"EmploymentType", type text}, {"ExperienceYears", Int64.Type},
        {"AnnualSalary", type number}, {"EmploymentStatus", type text}}, "en-US"),
    // 1. Remove duplicate employee rows
    Dedup = Table.Distinct(Typed, {"EmployeeID"}),
    // 2. Trim whitespace and standardise casing
    Trimmed = Table.TransformColumns(Dedup, {{"JobRole", Text.Trim, type text}, {"Department", each Text.Proper(Text.Trim(_)), type text}, {"Gender", each Text.Proper(Text.Trim(_)), type text}}),
    FixHR = Table.ReplaceValue(Trimmed, "Hr", "HR", Replacer.ReplaceValue, {"Department"}),
    // 3. Impute missing salary with the median for the same Department + JobRole
    Grouped = Table.Group(FixHR, {"Department", "JobRole"}, {{"MedianSalary", each List.Median([AnnualSalary]), type number}}),
    Joined = Table.NestedJoin(FixHR, {"Department", "JobRole"}, Grouped, {"Department", "JobRole"}, "G", JoinKind.LeftOuter),
    Expanded = Table.ExpandTableColumn(Joined, "G", {"MedianSalary"}),
    Imputed = Table.AddColumn(Expanded, "Salary", each if [AnnualSalary] = null then [MedianSalary] else [AnnualSalary], type number),
    Cleaned = Table.RemoveColumns(Imputed, {"AnnualSalary", "MedianSalary"}),
    // 4. Derived columns
    AsOf = Date.From(DateTime.LocalNow()),
    Tenure = Table.AddColumn(Cleaned, "TenureYears", each Number.Round(Duration.Days((if [TerminationDate] = null then #date(2026,9,30) else [TerminationDate]) - [HireDate]) / 365.25, 1), type number),
    AgeBand = Table.AddColumn(Tenure, "AgeBand", each if [Age] < 25 then "<25" else if [Age] < 35 then "25-34" else if [Age] < 45 then "35-44" else "45+", type text),
    ExpBand = Table.AddColumn(AgeBand, "ExperienceBand", each if [ExperienceYears] < 3 then "0-2 yrs" else if [ExperienceYears] < 7 then "3-6 yrs" else if [ExperienceYears] < 12 then "7-11 yrs" else "12+ yrs", type text),
    TenureBand = Table.AddColumn(ExpBand, "TenureBand", each if [TenureYears] < 1 then "<1 yr" else if [TenureYears] < 2 then "1-2 yrs" else if [TenureYears] < 5 then "2-5 yrs" else "5+ yrs", type text),
    SalaryBand = Table.AddColumn(TenureBand, "SalaryBand", each if [Salary] < 600000 then "<6L" else if [Salary] < 1000000 then "6-10L" else if [Salary] < 1500000 then "10-15L" else "15L+", type text),
    ReasonFix = Table.ReplaceValue(SalaryBand, null, "N/A (Active)", Replacer.ReplaceValue, {"ReasonForLeaving"})
in
    ReasonFix


// ---------- Query: Recruitment ----------
let
    Source = Csv.Document(File.Contents(DataFolder & "recruitment.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    Typed = Table.TransformColumnTypes(Promoted, {
        {"ApplicationID", type text}, {"RequisitionDate", type date}, {"Department", type text}, {"JobRole", type text},
        {"ApplicationDate", type date}, {"Source", type text}, {"FinalStage", type text}, {"HireDate", type date}}, "en-US"),
    Dedup = Table.Distinct(Typed, {"ApplicationID"}),
    // Stage reached flags make funnel DAX trivial (each application counts in every stage it reached)
    StageNo = Table.AddColumn(Dedup, "StageNumber", each
        if [FinalStage] = "Applied" then 1 else if [FinalStage] = "Screened" then 2 else if [FinalStage] = "Interviewed" then 3
        else if [FinalStage] = "Offered" then 4 else 5, Int64.Type),
    TimeToHire = Table.AddColumn(StageNo, "TimeToHireDays", each if [HireDate] = null then null else Duration.Days([HireDate] - [RequisitionDate]), Int64.Type),
    ReqMonth = Table.AddColumn(TimeToHire, "RequisitionMonth", each Date.StartOfMonth([RequisitionDate]), type date)
in
    ReqMonth


// ---------- Query: Performance ----------
let
    Source = Csv.Document(File.Contents(DataFolder & "performance.csv"), [Delimiter=",", Encoding=65001]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    Typed = Table.TransformColumnTypes(Promoted, {{"EmployeeID", type text}, {"ReviewYear", Int64.Type}, {"PerformanceRating", Int64.Type}}, "en-US"),
    Valid = Table.SelectRows(Typed, each [PerformanceRating] >= 1 and [PerformanceRating] <= 5),
    ReviewDate = Table.AddColumn(Valid, "ReviewDate", each #date([ReviewYear], 12, 31), type date)
in
    ReviewDate


// ---------- Query: Satisfaction ----------
let
    Source = Csv.Document(File.Contents(DataFolder & "satisfaction.csv"), [Delimiter=",", Encoding=65001]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    Typed = Table.TransformColumnTypes(Promoted, {{"EmployeeID", type text}, {"SurveyDate", type date}, {"WorkLifeBalance", Int64.Type}, {"Compensation", Int64.Type}, {"Management", Int64.Type}, {"CareerGrowth", Int64.Type}, {"WorkEnvironment", Int64.Type}, {"OverallSatisfaction", Int64.Type}}, "en-US"),
    // Unpivoted copy for the "factors" chart is built as a separate query (Satisfaction_Factors) below
    Nulls = Table.SelectRows(Typed, each [OverallSatisfaction] <> null)
in
    Nulls


// ---------- Query: Satisfaction_Factors (unpivoted, for factor analysis visual) ----------
let
    Source = Satisfaction,
    Unpivot = Table.UnpivotOtherColumns(Source, {"EmployeeID", "SurveyDate", "OverallSatisfaction"}, "Factor", "Score")
in
    Unpivot


// ---------- Query: Departments ----------
let
    Source = Csv.Document(File.Contents(DataFolder & "departments.csv"), [Delimiter=",", Encoding=65001]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    Typed = Table.TransformColumnTypes(Promoted, {{"Department", type text}, {"DepartmentHead", type text}, {"BudgetedHeadcount", Int64.Type}}, "en-US")
in
    Typed


// ---------- Query: Calendar (disable load of calendar.csv; build in M or use DAX version in measures.dax) ----------
let
    Source = Csv.Document(File.Contents(DataFolder & "calendar.csv"), [Delimiter=",", Encoding=65001]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    Typed = Table.TransformColumnTypes(Promoted, {{"Date", type date}}, "en-US"),
    Year = Table.AddColumn(Typed, "Year", each Date.Year([Date]), Int64.Type),
    Quarter = Table.AddColumn(Year, "Quarter", each "Q" & Text.From(Date.QuarterOfYear([Date])), type text),
    MonthNo = Table.AddColumn(Quarter, "MonthNo", each Date.Month([Date]), Int64.Type),
    MonthName = Table.AddColumn(MonthNo, "Month", each Date.ToText([Date], "MMM"), type text),
    YearMonth = Table.AddColumn(MonthName, "YearMonth", each Date.ToText([Date], "yyyy-MM"), type text),
    MonthStart = Table.AddColumn(YearMonth, "MonthStart", each Date.StartOfMonth([Date]), type date)
in
    MonthStart
