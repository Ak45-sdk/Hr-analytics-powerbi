# Report Design – Page-by-Page Build Guide

**Theme:** Navy `#1F3A5F` (primary), Teal `#2A9D8F` (positive), Amber `#E9A23B` (watch), Red `#D1495B` (risk), Grey `#8A94A6`.
Font: Segoe UI. Canvas 1280×720, light-grey background `#F7F9FC`, white card visuals with 8 px rounded corners.
Save theme as `theme/hr_theme.json` (included) → View → Themes → Browse for themes.

**Global slicers (synced across all pages via View → Sync slicers):** Department, Gender, Job Role, Education, Employment Status. Place them in a left rail on page 1 and a collapsible slicer *bookmark pane* on the other pages.

---

## Page 1 – Executive Overview
| Visual | Fields |
|---|---|
| 5 KPI cards | `Active Employees`, `Hires L12M`, `Attrition Rate %`, `Average Salary`, `Avg Performance Rating` |
| Clustered bar – Employees by Department | Employees[Department], `Active Employees` |
| Clustered bar – Employees by Job Role (top 10) | Employees[JobRole], `Active Employees` (Top N filter = 10) |
| Line chart – Monthly Hiring vs Attrition | Calendar[MonthStart]; `New Hires`, `Resignations` |
| Donut – Gender distribution; Donut – Employment Type | Employees[Gender] / [EmploymentType], `Active Employees` |
| Bar – Avg performance by department | Employees[Department], `Avg Performance Rating` |
Tooltips: custom tooltip page (see below). Drill-through target: **Employee Detail**.

## Page 2 – Recruitment Analytics
KPI cards: `Total Applicants`, `Hires (Recruitment)`, `Recruitment Success Rate %`, `Avg Time to Hire (Days)`, `Offer Acceptance Rate %`.
Visuals: **Funnel** (FunnelStages[Stage], `Funnel Stage Count`); column chart – applicants & hires by Source (+ `Recruitment Success Rate %` as line); line – `Avg Time to Hire (Days)` by month; matrix – department × `Avg Time to Hire`, `Recruitment Success Rate %` with data bars.

## Page 3 – Attrition & Turnover
KPI cards: `Exits L12M`, `Attrition Rate %`, `Early Attrition % (<2 yrs)`, `Top Reason for Leaving`, `Cost of Attrition (Est.)`.
Visuals: line – monthly `Resignations`; bar – `Cumulative Attrition %` by department (conditional colour via `Attrition Color`); **bar – reasons for leaving** (Employees[ReasonForLeaving], `Exits`, filtered ≠ "N/A (Active)"); column – attrition by TenureBand; decomposition tree – `Exits` explained by Department → JobRole → Education.

## Page 4 – Satisfaction
Cards: `Avg Satisfaction`, `Satisfied % (4-5)`, `eNPS-style Index`.
Visuals: clustered bar – `Factor Score` by Satisfaction_Factors[Factor] split by Employees[EmploymentStatus] (leavers vs active shows which factors differ); heat-map matrix – Department × Factor, colour scale on `Factor Score`; line – `Avg Satisfaction` by survey date; scatter – x `Avg Satisfaction`, y `Cumulative Attrition %`, size `Active Employees`, details Department; **Key influencers** visual – analyse `Satisfaction[OverallSatisfaction]` ≥ 4 explained by Department, SalaryBand, TenureBand, Education, Gender.

## Page 5 – Performance
Visuals: clustered column – `Avg Performance Rating` by Department; bar – by JobRole; line/column – by ExperienceBand; stacked 100 % column – rating distribution (1–5) by Department; scatter – Salary vs Performance; cards `High Performers %`, `Low Performers %`.

## Page 6 – Department Comparison
Table/matrix: Department, `Active Employees`, `Headcount vs Budget %`, `Total Payroll`, `Average Salary`, `Cumulative Attrition %`, `Avg Performance Rating`, `Avg Satisfaction`, `Attrition Risk Flag` – with conditional formatting (data bars on payroll, traffic-light icons on risk flag). Radar-style alternative: use Python/Deneb visual. Bar – `Salary Share %` vs `Headcount Share %`.

## Page 7 – Predictive Hiring
Visuals: **line chart with Analytics → Forecast** – Calendar[MonthStart] axis, `New Hires` value (forecast length 6 months, seasonality 12, 90 % confidence); cards `Expected Exits Next 12M`, `Growth Hires Needed`, `Projected Hiring Need (12M)`, `Months to Fill Gap`; clustered bar – projected need by department (`Expected Exits Next 12M` + gap); what-if parameter *Attrition improvement %* (Modeling → New parameter, 0–30 %) to show how lowering attrition cuts hiring need.

## Page 8 – Insights & Recommendations (text + KPI highlights)
Static text boxes populated from `docs/insights_and_recommendations.md`.

## Hidden pages
- **Tooltip – Department** (Page size: Tooltip; Allow use as tooltip): cards `Active Employees`, `Cumulative Attrition %`, `Avg Performance Rating`, `Avg Satisfaction` + mini line of monthly hires. Assign in Format → Tooltip of the department bar charts.
- **Employee Detail** (drill-through): drill-through field Employees[Department] (and Employees[JobRole]); table of EmployeeID, JobRole, TenureYears, Salary, Status, last rating, last satisfaction + back button. Right-click any department bar → Drill through → Employee Detail.

## Interactivity checklist
- Slicers synced on all pages · Edit interactions: KPI cards unaffected by their own trend chart
- Bookmarks: "Reset filters", "Show slicer pane"
- Page navigator (Insert → Buttons → Navigator → Page navigator)
- Conditional formatting on attrition/risk · dynamic titles via `Title – Attrition Trend`
- Row-level security (optional): Modeling → Manage roles → `Employees[Department] = USERPRINCIPALNAME() lookup` for department heads
